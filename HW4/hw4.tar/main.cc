#include "Phobic.h"
using namespace std;

int main() {
	Phobic a(3);
	a.get();
}
