#include <iostream>
using namespace std;

int main() {
    // How many CU students does it take to change a light bulb?
    cout << "Zero. They're too busy rioting.\n";
    return 0;
}
